//
//  AppDelegate.h
//  HugryTime
//
//  Created by 양예지 on 2018. 4. 30..
//  Copyright © 2018년 yangloria. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
- (void)startPresentationMode;
- (void)setSlideViewController;

@end

