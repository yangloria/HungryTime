//
//  SetAlarmViewController.h
//  HugryTime
//
//  Created by 양예지 on 2018. 5. 10..
//  Copyright © 2018년 yangloria. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetAlarmViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>

@end
