//
//  MainViewController.m
//  HugryTime
//
//  Created by 양예지 on 2018. 4. 30..
//  Copyright © 2018년 yangloria. All rights reserved.
//

#import "MainViewController.h"
#import "AppDelegate.h"
#import <PKRevealController/PKRevealController.h>
#import "LeftViewController.h"

@interface MainViewController () <PKRevealing>

@property (nonatomic, strong) PKRevealController *revealController;
@property (nonatomic, strong) IBOutlet UIButton *leftMenu;
@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    self.revealController.delegate = self;
   
//    [self.leftMenu addTarget:self.revealController action:@selector(leftOpen) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)startPresentationMode
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate setSlideViewController];
}

- (void)leftOpen
{
    [self.revealController leftViewController];
}


- (IBAction)leftMenuOpen:(id)sender
{
    [self.revealController showViewController:[self leftViewController]];
}

- (UIViewController *)selfView
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MainViewController *mainViewController = [storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    return mainViewController;
}

- (UIViewController *)leftViewController
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeftViewController *leftViewController = [storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
    return leftViewController;
}

- (IBAction)startFromNowOn:(id)sender
{
    
}

- (IBAction)selectStartTime:(id)sender
{
    
}

@end
