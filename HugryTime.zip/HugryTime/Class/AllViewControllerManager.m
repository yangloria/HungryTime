//
//  AllViewControllerManager.m
//  HugryTime
//
//  Created by 양예지 on 2018. 5. 3..
//  Copyright © 2018년 yangloria. All rights reserved.
//

#import "AllViewControllerManager.h"
#import "AppDelegate.h"
#import "LeftViewController.h"


@implementation AllViewControllerManager

//+ (void)openViewController:(UIViewController *)viewController animated:(BOOL)animated
//{
//    [[AppDelegate get].navigationController pushViewController:viewController animated:animated];
//}
//
//+ (BOOL)containsViewController:(Class)target
//{
//    for (UIViewController *vc in [AppDelegate get].navigationController.viewControllers) {
//        if ([vc isKindOfClass:target]) {
//            [[AppDelegate get].navigationController popToViewController:vc animated:YES];
//            return YES;
//        }
//    }
//    
//    return NO;
//}
//
//+ (void)openLeftViewControllerWithAnimated:(BOOL)animated
//{
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    LeftViewController *viewController = [storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
//    [self openViewController:viewController animated:animated];
//}

//example
//+ (void)openAccessAgreeViewControllerWithAnimated:(BOOL)animated
//{
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil];
//    AccessAgreeViewController *viewController = [storyboard instantiateViewControllerWithIdentifier:@"AccessAgreeViewController"];
//    [self openViewController:viewController animated:animated];
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
