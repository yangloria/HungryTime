//
//  SetAlarmViewController.m
//  HugryTime
//
//  Created by 양예지 on 2018. 5. 10..
//  Copyright © 2018년 yangloria. All rights reserved.
//

#import "SetAlarmViewController.h"

@interface LocalPushParam : NSObject
{
    NSInteger year;
    NSInteger month;
    NSInteger day;
    NSInteger hour;
    NSInteger minute;
    NSInteger second;
    NSString *eventName;
}
@end

@interface SetAlarmViewController ()

@property (nonatomic, strong) IBOutlet UIView *alarmCycle;
@property (nonatomic, strong) NSArray *kindOfTimeCycle;

@property (nonatomic, readwrite) NSInteger year;
@property (nonatomic, readwrite) NSInteger month;
@property (nonatomic, readwrite) NSInteger day;
@property (nonatomic, readwrite) NSInteger hour;
@property (nonatomic, readwrite) NSInteger minute;
@property (nonatomic, readwrite) NSInteger second;

@end

@implementation SetAlarmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.kindOfTimeCycle = [[NSArray alloc] initWithObjects:@"1시간 마다",@"2시간 마다",@"3시간 마다",@"4시간 마다",@"24시간 후", nil];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)setAlarmOnOff:(id)sender
{
    if([sender isOn])
    {
        NSLog(@"switch On");
        [self.alarmCycle setHidden:NO];
    }
    else
    {
         NSLog(@"switch Off");
        [self.alarmCycle setHidden:YES];
    }
}

//- (void)scheduleNotificationWithItem:(LocalPushParam *)item interval:(int)minutesBefore
//{
//
//    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
//    NSDateComponents *dateComps = [[NSDateComponents alloc] init];
//
//    [dateComps setDay:item.day];
//    [dateComps setMonth:item.month];
//    [dateComps setYear:item.year];
//    [dateComps setHour:item.hour];
//    [dateComps setMinute:item.minute + 5];
//
//    NSDate *itemDate = [calendar dateFromComponents:dateComps];
//
//    UILocalNotification *localNotif = [[UILocalNotification alloc] init];
//    localNotif.fireDate = itemDate;
//    localNotif.timeZone = [NSTimeZone localTimeZone];
//    localNotif.alertBody = [NSString stringWithFormat:NSLocalizedString(@"안전결제 프리미엄 서비스 이용안내", nil)];
//    localNotif.soundName = UILocalNotificationDefaultSoundName;
//    localNotif.applicationIconBadgeNumber = 1;
//
////    NSDictionary *infoDict = [NSDictionary dictionaryWithObjectsAndKeys:_item.eventName,@"EVENTKEY1", @"Local Push received while running", @"MSGKEY1", nil];
////    localNotif.userInfo = infoDict;
//
//    [[UIApplication sharedApplication] scheduleLocalNotification:localNotif];
//}
- (void)setAlarmOff
{
    
}

#pragma mark - picker component

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    //컴포넌트 갯수
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    //여러개면 Swith문으로 작성해야 함.
    return [self.kindOfTimeCycle count];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    [self.kindOfTimeCycle objectAtIndex:row];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    return [self.kindOfTimeCycle objectAtIndex:row];
}








@end
